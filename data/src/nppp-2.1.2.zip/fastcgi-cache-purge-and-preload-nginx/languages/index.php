<?php // Silence is golden 
