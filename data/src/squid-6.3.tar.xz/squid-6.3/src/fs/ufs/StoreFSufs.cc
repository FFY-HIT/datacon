/*
 * Copyright (C) 1996-2023 The Squid Software Foundation and contributors
 *
 * Squid software is distributed under GPLv2+ license and includes
 * contributions from numerous individuals and organizations.
 * Please see the COPYING and CONTRIBUTORS files for details.
 */

/* DEBUG: section 47    Store Directory Routines */

/*TODO: remove this file as unused*/

#include "squid.h"
#include "fs/ufs/StoreFSufs.h"
#include "fs/ufs/UFSSwapDir.h"

/* Unused variable: */
Fs::Ufs::StoreFSufs<Fs::Ufs::UFSSwapDir> *UfsInstance_foo = nullptr;

